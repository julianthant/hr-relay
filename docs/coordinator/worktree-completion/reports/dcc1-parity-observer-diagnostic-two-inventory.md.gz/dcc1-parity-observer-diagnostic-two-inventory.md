# sup_sol_dcc1_two_inventory_diagnostic

## Status and scope

Diagnostic execution complete, **12 actual accessibility-reference failures; gate 1 / logger 0**.
Heavy slot released immediately at terminal; observer restored exactly before analysis. No
screenshot-assertion pass, reference disposition, source repair, stage, or commit is claimed.
Same native sup_sol/Sol, high reasoning, assigned 240k/220k; no new task/agent/worktree. The
native tool has no task_name field; this exact role prefix records the approved schema limitation.

Only the previously reviewed temporary capture observer was installed; the supplemental
architecture test stayed baseline throughout. Permanent outputs are this report, three declared
JSON receipts, raw/meta, 12×7 observed files, and the separate runner's 13 files. No new tests,
lint, coverage, browser probes, or follow-on commands ran. This execution-only grant expressly
did not authorize fresh lint; prior preparation/proof light receipts remain historical.

I used /supervise for the assigned-unit/slot boundary, /ui's repository parity evidence route,
and /hr-debug with global debug for observed-red evidence. Those skills did not expand the
operator's no-live/no-repair/no-reference-update authority.

## Admission and exact two-inventory correction

Read the complete two-inventory handoff and parent receive report/JSON. Original input admission
**1e8402 exit 0**, at 2026-08-30T19:19:35.508Z, preceded every new output. It verified all current
307 visible records by exact path/bytes/SHA256/mode, every fixed copy, source/reference/dependency
pins, and all 15 absent case/runner/raw/meta destinations.

The coordinator's corrected decomposition is retained, not replaced by a count:

- O: original admission's 278 exact paths.
- R: six prior non-copy receipts plus the three explicitly pinned parent outputs; subsequent
  declared receipts are added individually.
- C: fixed manifest's 112 preservation destinations, independently physically walked.
- I: only C's unique `git check-ignore -v -z --stdin` results, with exact source/line/pattern/path.
  The observed 92 ignored dist entries use `.gitignore:45`; this is not a hardcoded exemption.
- Required predicates: physical files at preservation root == C, and Git-visible untracked
  files == O ∪ R ∪ (C − I), with unique/disjoint sets. Copies and originals must retain exact
  byte lengths, hashes and modes; symlinks, non-regular files and extra files refuse.

The existing preservation root was verified and reused; nothing was recopied, removed or
overwritten. Initial observed union was 278+9+20=307 visible / 399 physically declared files.
After the new command/admission files, corrected read-only admission **b41303 exit 0** verified
278+11+20=309. The complete original and replacement lexical blocks are in
[command receipt](../evidence/dcc1-parity-observer-diagnostic-command-two-inventory.json).
Outside that inventory block, only the command artifact's self-path changed; postflight checked
exact transformation and unchanged executable/args/env/run/logger semantics.

The earlier 95374, 52914 and c006ea failures remain failed, immutable historical receipts.
The old ae87e77b command and 8dd76a36 postflight were not repaired in place or waived.

## Actual execution and release

Exactly once, cwd `/Users/julianhein/.codex/worktrees/c9fb/r-dcc-units/dcc1`:

```sh
/usr/bin/lockf -k -t 0 /tmp/hr-dashboard-full-gate.lock env -u PARITY_UPDATE HRAUTO_LEGACY_REPO=/Users/julianhein/Projects/hr-automation VITEST_MAX_WORKERS=1 npm run test:parity -- tests/parity/dashboard-reference.spec.ts --grep 'explorer-(graph|transaction)$' --output=tests/parity/.output/dcc1-explorer-diagnostic-01
```

Native session **70130**; launch chunk f5852a, polls a6539e/e9c3c8, terminal a6cfe7.
Start **2026-08-30T19:20:41.901Z**; terminal **19:21:08.053Z**; **26.155046125 seconds**.
One worker, exactly 12 selected tests, all 12 failed a11y reference comparison.
lockf child PID 17210; gateExit **1**, loggerExit **0**, wrapperExit **1**, signal null,
logger errors empty. No retry, kill, lock unlink, concurrent own light command or second browser
command. The natural terminal released the OS lock.

Immediate app RELEASE messages went to parent
`01a052ed-faf3-7a33-b0be-9fd404bc4cc6` and coordinator
`01a04b28-14a3-7362-8778-4543583d9a16` before restoration, interpretation or report work.
No owned process remains active; this is not a reservation for any next gate.

[Raw log](../evidence/dcc1-parity-observer-diagnostic.raw.log): **48542 bytes**,
SHA256 `78638c6cb5683325b73f470f0d1701023cd48979f5c01c9746c911a0806c1b7c`.
[Metadata](../evidence/dcc1-parity-observer-diagnostic.meta.jsonl): **746377 bytes**,
SHA256 `57cfb802c3f8be5424242564d75f7973eb5dd82fa40b51521d11aec1e52a10cd`.

Raw child stdout/stderr buffers were written and fsynced before tool transport, preserving callback
arrival order. Start/spawn/terminal records and the complete actual input map/closure were separately
persisted. Terminal tool transport was truncated; it is not the raw log and is not used as a
complete byte receipt. Structured postflight and offline diff output are annotated read-only
receipts parsed from tool transport, not relabeled disk-first raw streams.

## Executed inputs, restoration, preservation

| Pin | Exact identity |
| --- | --- |
| HEAD | `0c115123a738f62cbe01c9b45f53b7289284479c` |
| ordered MERGE_HEAD | `13175b13340fec7b5326207fe54f98078d481d7d` |
| complete unchanged index | `ae00723e05d20a6c87d0ada500fc77a456870ea9` |
| restored capture | `641378037d2396a6e84003115a5f158f178e17c7` |
| executed observer | `31776c251399a9b945822c7d796b44468fb6cadd` |
| unchanged architecture test | `6bdebc160f537079eeea8c4db6369ad1069ab9e1` |
| unchanged reference store | `58fec850d0e0140b6ab45fb8fb341d940a16d44f` |
| actual gate-time ordered execution closure | `7539930ac1b653fda3c84071d0406efa2313d509d3f71b79fe16e8b55c933bbb` |
| restored ordered execution closure | `d681c0c5a4d7e2764d40f231e1f5f3650a838b044264a5a37077235de1f18051` |

The gate-time metadata contains all **1923** actual working input records and the ordered stream,
derived and fsynced before spawn. This is an actual contemporaneous observation; the earlier
virtual observer-only 7539930a receipt remains labeled virtual. Postflight verified the actual
map was exactly the frozen map with only capture's blob substituted.

Immediately after terminal, reverse apply_patch restored capture; **9627aa exit 0** verified
capture/test/refstore/parents/index. Complete read-only postflight **c71222 exit 0**, at
**2026-08-30T19:22:16.918Z**, verified every non-coordination tracked file, **603 reference files**,
dependency/browser/legacy guard pins, all prior visible records, retained originals and 112 copies.
No unmerged entries; both diff checks exit 0. Only the parent's existing reports/dcc1.md was
unstaged. The pending merged index was never staged or committed by this unit.

All original 15 parity outputs, old raw/meta, 40 plaintext originals plus their archives, proof
artifacts, and preserved outputs remained exact. The new runner owns **13** distinct files
(12 error-context files and .last-run.json), separately inventoried. Each of 12 observer directories
owns exactly seven files; actual files are 0600 and references 0644. Full paths/hashes/sizes/modes
are in the structured postflight, including the current runner files.

At the postflight boundary, O278 + R97 + visible-C20 = **395 Git-visible** entries; all112 physical
copies were independently retained (487 physically declared O/R/C files). R97 includes the
explicit command/admission, raw/meta and 84 observed files, without double-counting copies.
The two final packaging paths are declared separately and were both absent in **78977e exit 0**.
These are lifecycle observations, not a fabricated creation-time self-hash or a new count policy.

## Bundle provenance

The normal lane **reused the existing valid stamped bundle**; it did not mint a new stamp.
All600 build inputs and91 outputs were independently rehashed. All91 output files plus the
stamp remained byte-identical to their preserved old copies.

- Actual stamp: `dist/dashboard/parity-build-stamp.json`, 266 bytes, SHA256
  `20773190626ec0f7bbc914f46c00d5610a0cc1aa58735eef25e27ca43286246e`.
- Actual builtAt: `2026-08-30T17:39:58.194Z`, not this diagnostic's launch instant.
- Input digest: `f3b154df374d21e1f107ba31219ef339e2747c0aab53ee89aef127950c06dae4`.
- Output digest: `87f1d808ff832b32a1a6ddfb4a99c7088e91bbea7ccd660fbdc21c1c888d5be7`.
- Exact old stamp bytes remain at
  [preserved stamp](../evidence/dcc1-parity-observer-diagnostic-preserved/dist/dashboard/parity-build-stamp.json).

No wrong/stale-bundle or untracked executable drift was observed against these pinned inputs.
The source hash attribution already retained in [parity cause](dcc1-parity-cause.md) remains the
source/history evidence: whole-file/type import closure through base task/providers and
domain/provider-admission reaches config/schema.ts; that is the one changed source in the
50/51-file task closures compared with frozen13175. Current captured fingerprints equal that
reviewed closure derivation. This report does not invent new reference provenance or re-run that
history investigation.

## Complete 12-case comparison

Every complete actual a11y file was diffed against the unchanged matching reference, not merely
the printed first mismatch. Each has **one hunk, one removed line and one added line**; the sole
difference is one implementation fingerprint:

- **G**, graph line150: `fe99beff4f72 → 843937a26347`.
- **T**, transaction line143: `692804fed6ae → 847db5229dea`.

No additional contract rows, duplicate fingerprint changes, other text, descriptor/schema hash
or semantic-tree difference appeared. Every actual metadata file is byte-identical to reference.
Complete unified hunks and full artifact/reference hashes are retained in the postflight JSON.

PNG columns are read-only exact decoded-RGBA differences, **not a screenshot assertion**.
Bounds are inclusive; maxΔ is maximum absolute channel difference, without mask or threshold.

| Full case name | Sole a11y line/change | Metadata | Changed PNG pixels / maxΔ | Pixel bounds | Saved PNG pair |
| --- | --- | --- | --- | --- | --- |
| explorer-graph--graphite-warm--1280x720 | 150 · G | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--graphite-warm--1280x720/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--graphite-warm--1280x720.png) |
| explorer-transaction--graphite-warm--1280x720 | 143 · T | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--graphite-warm--1280x720/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--graphite-warm--1280x720.png) |
| explorer-graph--paper-ink--1280x720 | 150 · G | equal | 8 / 11 | 20,16–27,17 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--paper-ink--1280x720/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--paper-ink--1280x720.png) |
| explorer-transaction--paper-ink--1280x720 | 143 · T | equal | 121 / 16 | 265,9–1217,642 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--paper-ink--1280x720/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--paper-ink--1280x720.png) |
| explorer-graph--graphite-warm--1440x900 | 150 · G | equal | 10 / 13 | 20,16–27,17 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--graphite-warm--1440x900/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--graphite-warm--1440x900.png) |
| explorer-transaction--graphite-warm--1440x900 | 143 · T | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--graphite-warm--1440x900/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--graphite-warm--1440x900.png) |
| explorer-graph--paper-ink--1440x900 | 150 · G | equal | 158 / 2 | 265,9–1153,734 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--paper-ink--1440x900/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--paper-ink--1440x900.png) |
| explorer-transaction--paper-ink--1440x900 | 143 · T | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--paper-ink--1440x900/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--paper-ink--1440x900.png) |
| explorer-graph--graphite-warm--narrow-1024x768 | 150 · G | equal | 10 / 14 | 687,9–961,11 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--graphite-warm--narrow-1024x768/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--graphite-warm--narrow-1024x768.png) |
| explorer-transaction--graphite-warm--narrow-1024x768 | 143 · T | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--graphite-warm--narrow-1024x768/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--graphite-warm--narrow-1024x768.png) |
| explorer-graph--paper-ink--narrow-1024x768 | 150 · G | equal | 0 / 0 | — | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-graph--paper-ink--narrow-1024x768/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-graph--paper-ink--narrow-1024x768.png) |
| explorer-transaction--paper-ink--narrow-1024x768 | 143 · T | equal | 12 / 16 | 685,9–961,11 | [actual](../evidence/dcc1-parity-observer-capture-01--explorer-transaction--paper-ink--narrow-1024x768/post-refusal.png) · [reference](../../../../tests/parity/references/explorer-transaction--paper-ink--narrow-1024x768.png) |

All12 actual PNGs and the six differing reference PNGs were viewed locally after release.
No visible structural/content/theme delta was apparent; six other reference PNGs were
byte-identical to the viewed actuals. This visual observation is not an acceptance waiver,
and exact pixel differences are not claimed absent or explained by a guessed cause.
The offline decoder command **5407fd exit 0** used installed Playwright PNG.sync.read,
whose bundle hash and complete script/results are retained in the postflight. It did not call
the screenshot comparator, create images, change pixels, or run a browser.

Actual/ref a11y SHA256 pairs:

| Full case name | Reference SHA256 | Actual SHA256 |
| --- | --- | --- |
| explorer-graph--graphite-warm--1280x720 | `78396a2acc566d11b31ecddc8b70d799aba87fb5b98b0ebbabd2e29ff24082df` | `83326e806e07a002d04b7a2feb44fe54a392dd50c793c22cb1eee7447f6491f0` |
| explorer-transaction--graphite-warm--1280x720 | `e334f8dcf1beca30cc4e38165d881d7b2cbfdda0ed4f117d5333a4d3993b838e` | `bcc44c8430091a574a5d61794ce0b4268dd04cbe24bdba55476ea2816f92e549` |
| explorer-graph--paper-ink--1280x720 | `b25a3d46eff1d43a4fd5c406192c2bddb9242bdef29bcd7d22ab814585ceaa3d` | `57a0802027101ea06d943ca8ef3f6cccb5a873bdc4eb6180ff9a83e021d4282d` |
| explorer-transaction--paper-ink--1280x720 | `1a9e31188b58d4a7b687c565bc9753914be11f14a3665a2ba48bc5325bf8a999` | `1095aa53f6f52391b93af3bfd2d6a9464754c673cbed63fb4309ad341617fb77` |
| explorer-graph--graphite-warm--1440x900 | `0ebc5063496c613a1cbba472f916f6a9372672ddbb6b13ae9e6724885e3fa6f7` | `979eda0d91c8c1e8050b8444f8dea312a375feea4d05e19902926ec4414bd521` |
| explorer-transaction--graphite-warm--1440x900 | `5899d015ef580f64afa4b8152c4c4c91025c653cd1a799843518f9ebeffa03b8` | `39525724d25ae1c42719a58cebb1d61d85a9cd9375cc50297c8e284950af70c7` |
| explorer-graph--paper-ink--1440x900 | `af94c88b5d703b6d7db36027255506e8a5ee8ea960c08f6d7c91cecc68beb9a1` | `3386b1e2b1de5d35cc73d84e34b25b3af6eaed957f17e13bb733aea669a75474` |
| explorer-transaction--paper-ink--1440x900 | `13db1ead1ab87723f77c4badcf402b7faddc7dc35140ae9ef293e6f20518de03` | `b12338152ab19e4e586671113097c5fa99c6e007c3d007d6d81909d3f7e5f1b1` |
| explorer-graph--graphite-warm--narrow-1024x768 | `7bf39e5362c0cc9306d30f4cde3b5644276c6c6367c014b4a82dbe14149f14e9` | `1424d1febd46098f07f41293de0a68604812be49bf66a5d62ada46951a8bea52` |
| explorer-transaction--graphite-warm--narrow-1024x768 | `64a11f46c82c00ebb6c9ac537ad1f6bae3d13e082b8e98e5f67eaf7bcc2293b3` | `b2cb9778e34935cb5a8b35d39e0e98df17864e37d32985c8cdd7b0ab0d26b611` |
| explorer-graph--paper-ink--narrow-1024x768 | `fc9c837acd4e7077acb16b966ed987e3ccd9d3060a5b8dfb1a6aae94f644b2c4` | `017713bb7cf937eeb253b153bf0dfd3aadad4a633e2a7593819ed7a688dc8cea` |
| explorer-transaction--paper-ink--narrow-1024x768 | `dd0d8deaa9857ddc5ded677290ad3b0fcd3f95d0f1899ab073ce2f1a628569f6` | `ad4c996b93dbf44cf7976c385b709108520274968ae98d21e69d15124a987e1d` |

### Capture and assertion chronology

For each case the reviewed observer reused the original **single ariaSnapshot** tree.
It persisted tree.txt, serialized actual.a11y.yml/actual.meta.json and before-assertion.json
before the unchanged original comparison. On its real refusal it recorded a separately timed
post-refusal-start.json, diagnostic post-refusal.png and post-refusal-end.json, then propagated
the original error. All seven files exist for each case; no AggregateError or observer secondary
failure appears in the raw output. Other fault-path guarantees remain the earlier proof's scope.

Actual before-assertion instants range **19:20:45.221Z–19:21:07.881Z**;
PNG completion instants **19:20:45.295Z–19:21:07.938Z** on2026-08-30.
Each case's exact before/start/end/PID is retained. PNGs are later observations, not asserted
to be the same instant as ariaSnapshot.

Metadata's `capturedAt: 2026-08-03` is fixed fixture metadata, **not wall-clock capture time**.
The original assertion stopped at a11y drift. Thus metadata equality is an offline observation,
and screenshot assertions were **not reached**. Error-context files are error/test-source
artifacts, not mislabeled accessibility captures; the observer's tree/actual.a11y files now supply
that previously missing evidence.

### Independently reported parent analysis

Parent reported c1c252 verified actual renderA11yReference(tree,meta) byte equality for all12,
and81e866 found the same exact pixel counts with no alpha differences. Parent1b68a5 invoked
the installed real `coreBundle.js` PNG comparator on saved buffers using unchanged
threshold0.2/maxDiffPixels0 and received null for all12 (library SHA prefix6be5c2ea,
config4da79d61). Parent owns those scripts/results and full hashes; these are **not worker
executions**, and I did not duplicate them. They are read-only library comparisons, not browser
or screenshot-assertion passes. Parent also directly viewed all12actual/six differing references.

## Retained receipts and boundaries

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| [Corrected command](../evidence/dcc1-parity-observer-diagnostic-command-two-inventory.json) | 130436 | `3f55deea87499fa8fac8e99bfbcab623fd14b396519089743b9d808dad99f610` |
| [Admission](../evidence/dcc1-parity-observer-diagnostic-two-inventory-admission.json) | 424396 | `6773a3b3c52f7d7895f0cd31aabc2cdad1a0c12941e1694450f30cccfa2979e9` |
| [Postflight, full12 diffs, PNG analysis and restoration](../evidence/dcc1-parity-observer-diagnostic-two-inventory-postflight.json) | 509860 | `423a7e6996774a0a712dc4895b060aee20dbefcdb4eb1588beecf967150e95be` |

Artifact hashes above were read after creation in e4f9fa exit0. This report's hash is returned
separately, avoiding recursive self-hashing. New report/JSON paths are explicit lifecycle entries;
no broad prefix exemption or ignore/config change was introduced.

Original full coverage335files/3806tests green and fullparity227passed/12failed remain historical,
unchanged. This diagnostic establishes the complete saved semantic delta and supplies real
post-refusal images; it does not grant full parity acceptance. Following ref
frontend-backend-integration §7 and lessonsD132/D187, source/build/reference evidence must stay
bound and reference changes require their own disposition. The smallest attributable next
decision is parent review of these exact12 pairs and the existing reviewed fingerprint-closure
change—not a whole-corpus refresh or source workaround. No disposition is implemented here.

Parent independent receive/review remains required. All reference-update, source-repair,
follow-on gate, staging/commit, migration/D75/shared-integration/live-authority actions remain
excluded. Cross-run migration collision and D75 residue are unchanged; no global compatibility
claim. All owned commands are terminal and the slot has already been released.

