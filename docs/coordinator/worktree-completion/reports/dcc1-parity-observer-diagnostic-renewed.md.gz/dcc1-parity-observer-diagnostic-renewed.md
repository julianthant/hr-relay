# sup_sol_dcc1_parity_observer_diagnostic_renewed

STATUS: **Launcher admission refused; browser NOT RUN. Heavy slot RELEASED; source restored.**  
ROLE / MODEL / REASONING: same native sup_sol / Sol / high, assigned 240k/220k.  
COMMITS: none. No staging, index change, source repair, reference update or retry.

## Result and exact boundary

The approved renewed preflight passed. All112 old files were exclusively preserved, and the
reviewed observer31776 was installed. The launcher then exited1 at its Git-visible untracked-set
comparison, **before deriving/persisting its actual instrumented input map, opening diagnostic
raw/meta files, reserving the runner directory, or spawning lockf/npm/Playwright**.

Its expected set wrongly included ignored preservation descendants in a
`git ls-files --others --exclude-standard` result. This is a launcher accounting defect, not
a parity failure, missing copy, source drift or reference verdict. No heavy OS lock was acquired.
The exact command/source and actual returned failure are retained in
[command](../evidence/dcc1-parity-observer-diagnostic-command.json) and
[postflight](../evidence/dcc1-parity-observer-diagnostic-postflight.json).

Immediate terminal RELEASE notices succeeded to parent
`01a052ed-faf3-7a33-b0be-9fd404bc4cc6` and coordinator
`01a04b28-14a3-7362-8778-4543583d9a16`, before interpretation/report work.
Exact apply_patch restoration followed. Explicit restoration receipts were sent to both.
No owned process remains; no NEXT or follow-on authority is inferred.

## Execution receipts

| Operation | Actual receipt / outcome |
| --- | --- |
| Updated preflight | tool0f0a5f, synchronous exit0; child PID15299, no yielded session; inventory exit0/logger0 |
| Preflight time | 2026-08-30T19:09:44.862Z–19:09:45.711Z; elapsed0.858816042s |
| Original inventory | exact278 membership/size/SHA256/mode before ANY new output |
| Other preflight checks | 1923 tracked;1511 retained;112 preservation-plan records;16 prospective paths absent;13 child commands all exit0 |
| Preservation | tool02f655 exit0;112 exclusive copies, bytes/hash/modes exact;19:10:05.729Z–19:10:06.262Z |
| Observer install pin | tool60dcef exit0: capture31776, test6bde, refstore58fe |
| Launcher | toolc006ea, synchronous exit1; no yielded session; assertion “exact declared non-execution inputs” |
| Browser/gate/logger | NOT STARTED; exits/session not applicable; no diagnostic raw/meta files |
| Post-release restoration check | toolf35d25 exit0; bounded overall pass flag FALSE solely for erroneous guessed107 ignored-count predicate, disclosed below |
| Exact ignore classification | tool0efba5 exit0:92 ignored +20 visible copies; every classification belongs to fixed manifest |

[Admission](../evidence/dcc1-parity-observer-diagnostic-admission.json) retains the exact wrapper,
transport receipt, preservation script, full fixed112-copy manifest and copy receipt.
The baseline corrected command changed only the explicitly approved non-execution inventory block
to exact277 ledger entries plus its separately pinned self; the earlier mapping correction remained.
Source/reference/retained/dependency predicates were not dropped or broadened.
Updated stdin-source SHA256:
`6ba0063f6e3ed91fe79124cf1559bb0a41650a49a7e8966026e896227bdde7c7`.

Original95374 remains failed. Corrected52914 remains exit1/logger0 on the historical inventory
checks. Neither is relabeled by this renewed preflight green.

### Raw versus transport evidence

The new admission process completed its comparison before the wrapper created output files.
It held child buffers in memory, then exclusively wrote/fsynced the complete raw bytes and
separate start/terminal metadata **before compact tool transport**. Start time was observed before
spawn, but those metadata bytes were persisted after terminal; no contemporaneous-on-disk start
claim is made. The raw file is complete structured JSON from the inventory process; nested Git/npm
stdout is encoded data, not separately captured raw streams.

The launcher failed before opening its disk-first logs. Its actual tool-returned error text is
**truncated transport evidence** (tool reported10242 original tokens), preserved without
normalization in postflight. There is no complete raw launcher/browser log and no fabricated one.
Exact launcher source is complete and immutable in command.json; postflight diagnosis does not
reconstruct omitted error-output bytes or imply a browser execution.

## Physical versus Git-visible accounting

The exact fixed112 preservation manifest contains:

| Preserved group | Physical files | Git-visible here |
| --- | ---: | ---: |
| Old emitted bundle plus actual old stamp | 92 | 0 |
| Old15 parity outputs | 15 | 15 |
| Old five gate/evidence files | 5 | 5 |
| Total |112|20|

`git check-ignore -v -z --stdin` over ONLY those112 manifest paths identifies all92 exclusions
as **.gitignore:45:dist/**. No classification lies outside the manifest. The copied `.output`
descendants are NOT excluded here: that existing ignore rule is rooted differently. The initial
release message's “dist/.output” wording was an overbroad inference; the recorded classification
above is the verified explanation.

At launcher time, the exact physical expected membership was278 originals + four declared
non-copy receipt files +112 copies =394. Git showed302, exactly the same set minus92 ignored
copies, with no unexpected visible paths. Physical directory traversal separately matched
all112 manifest paths and verified their unchanged bytes/modes. Copies were not missing.

The first read-only postflight mistakenly hard-coded a guessed107 ignored count. Its actual
record has `pass:false` and `failures:["107 preserved ignored files"]`; exit0 merely means that
script completed. All other encoded checks passed. The script/output are retained unchanged.
The subsequent exact-path ignore read is classification evidence, **not a count-adjusted rerun**.

### Minimal correction PROPOSAL ONLY

Use two exact inventories, with no hard-coded ignored count and no broad report/path exclusions:

1. **Physical preservation:** walked file set equals the fixed copy-manifest paths exactly;
   every file is regular/non-symlink with exact original/preserved bytes, SHA256 and mode.
2. **Git-visible:** let `C` be those manifest paths, `I` their exact Git ignore classification,
   `O` the frozen original non-execution paths, and `R` the exact separately declared non-copy
   receipt paths. Require `GitUntracked === O ∪ R ∪ (C − I)`, retaining ignore-rule provenance
   and refusing any classification outside `C`.

Keep all original hash/mode/source/reference/dependency predicates. Any future invocation must
freshly pin final receipt additions by exact path/hash and obtain authority; this proposal neither
advances that inventory nor implements/runs a repaired launcher. No predicate, ignore rule or
configuration was changed.

## Restored source and retained outputs

At **2026-08-30T19:12:07.416Z**, f35d25 verified:

| Identity | Exact value |
| --- | --- |
| HEAD |0c115123a738f62cbe01c9b45f53b7289284479c|
| Ordered MERGE_HEAD |13175b13340fec7b5326207fe54f98078d481d7d|
| Complete index |ae00723e05d20a6c87d0ada500fc77a456870ea9|
| Restored execution closure |d681c0c5a4d7e2764d40f231e1f5f3650a838b044264a5a37077235de1f18051|
| capture.ts |641378037d2396a6e84003115a5f158f178e17c7|
| Architecture test |6bdebc160f537079eeea8c4db6369ad1069ab9e1|
| reference-store.ts |58fec850d0e0140b6ab45fb8fb341d940a16d44f|

All1923 working tracked execution files matched the index, including603 references.
All278 original coordination inputs,1511 retained checks,112 copies and corresponding originals
matched. Both Git diff checks exited0; only the existing parent dcc1.md was unstaged, no unmerged
entries. All12 observer directories, runner and diagnostic raw/meta remained absent.

The actual old stamp is still266 bytes, SHA256
`20773190626ec0f7bbc914f46c00d5610a0cc1aa58735eef25e27ca43286246e`, with its byte-identical
preserved copy under `evidence/dcc1-parity-observer-diagnostic-preserved/dist/dashboard/`.
Old build time remains2026-08-30T17:39:58.194Z; input digest
`f3b154df374d21e1f107ba31219ef339e2747c0aab53ee89aef127950c06dae4`, output digest
`87f1d808ff832b32a1a6ddfb4a99c7088e91bbea7ccd660fbdc21c1c888d5be7`.
No normal build occurred and no new stamp was minted.

## Artifact identities and remaining limits

| Evidence | Bytes | SHA256 |
| --- | ---: | --- |
|dcc1-parity-observer-diagnostic-admission.raw.log|708854|abb4c4b52f084ff249917d407f1622e3b008b5b571384b0bbead66e33fcfce5f|
|dcc1-parity-observer-diagnostic-admission.meta.jsonl|7987|42bdb4ebfb4e2b5785710b54a4cc0210967878464684a77a8b7b2ee53ed31918|
|dcc1-parity-observer-diagnostic-admission.json|141187|5f70e731063fa20a7023c35ee7be87be64c6c547bd75def30ea95177114dbce4|
|dcc1-parity-observer-diagnostic-command.json|14073|ae87e77b313c47fd584e21657fc8cd637cb647dd77c3df59fb363d542fcecb85|
|dcc1-parity-observer-diagnostic-postflight.json|542248|8dd76a36f3a28971892c2759ab21530b2157aae72dbe7f49c9ee684c1661420b|

The postflight records the precise original278 and declared new-file lifecycle. This report and
postflight were created after its restoration inventory; no recursive self-hash or false
creation-time final hash is claimed. The112 copies remain in their exclusive directory, including
ignored descendants, and all40 plaintext originals/archives and earlier handoffs are untouched.

No actual12 trees/meta/PNGs or screenshot assertions were produced. Historical coverage335/3806
green and parity227pass/12fail remain unchanged. The observer-only7539930a closure was NOT
contemporaneously emitted by this failed launcher; historical virtual derivation remains historical.
No pixel/UI acceptance, reference disposition, source repair, or full-gate acceptance is implied.
D132/D187 and ref frontend-backend-integration §7 still require complete semantic and visible
evidence. /ui and /hr-debug shaped the evidence distinctions; /supervise kept this to the same unit.
Migration/D75, archive durability, pending merge and shared integration remain excluded/open.
